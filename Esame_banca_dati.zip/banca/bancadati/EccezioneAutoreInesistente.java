package bancadati;

@SuppressWarnings("serial")
public class EccezioneAutoreInesistente extends Exception {

}
