package bancadati;

@SuppressWarnings("serial")
public class EccezioneProdottoInesistente extends Exception {

}
