package bancadati;

@SuppressWarnings("serial")
public class EccezioneAutoreEProdottoInesistenti extends Exception {

}
